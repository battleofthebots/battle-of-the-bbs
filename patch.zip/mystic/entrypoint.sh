#!/bin/bash
#
rm /mystic/semaphore/mis.bsy
rm /mystic/logs/*.log
/mystic/mis server
